#!/bin/bash

# Install OpenJDK 8
apt-get update
apt-get install -y openjdk-8-jre
echo 'JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64/jre' >> /etc/environment
source /etc/environment

# Install Net Tools
apt update
apt install -y net-tools

# Get the Cassandra 3.11.x repository
echo "deb https://downloads.apache.org/cassandra/debian 311x main" | tee -a /etc/apt/sources.list.d/cassandra.sources.list
curl https://downloads.apache.org/cassandra/KEYS | apt-key add -
apt-get update
if ["$?" = 1]; then
  apt-key adv --keyserver pool.sks-keyservers.net --recv-key A278B781FE4B2BDA
  apt-get update
fi

# Install Cassandra 3.11.x
apt-get -y install cassandra
service cassandra stop

# Get the VPC private IP
my_ip_var[0]=$(ifconfig | grep -m1 inet | awk '{print $2}')
my_ip_var[1]=$(echo $my_ip_var | awk '{split($0,a,"."); print a[1]}')
my_ip_var[2]=$(echo $my_ip_var | awk '{split($0,a,"."); print a[2]}')
my_ip_var[3]=$(echo $my_ip_var | awk '{split($0,a,"."); print a[3]}')
my_ip_var[4]=$(echo $my_ip_var | awk '{split($0,a,"."); print a[4]}')

# This is the cluster name for the Cassandra cluster
my_cluster_name_var='SparkyHive Cluster'

# Replace default cluster name with my_cluster_name_var
sed -i "10s/cluster_name: 'Test Cluster'/cluster_name: '$my_cluster_name_var'/" /etc/cassandra/cassandra.yaml

# Replace localhost with own IP address for the listen address
sed -i "612s/listen_address: localhost/listen_address: ${my_ip_var[1]}\.${my_ip_var[2]}\.${my_ip_var[3]}\.${my_ip_var[4]}/" /etc/cassandra/cassandra.yaml

# Replace SimpleSnitch with Ec2Snitch
sed -i "962s/endpoint_snitch: SimpleSnitch/endpoint_snitch: Ec2Snitch/" /etc/cassandra/cassandra.yaml

reboot
