import os
import csv

refined_path = "../AirflightDelays/merged_refined/"
nonull_path = "../AirflightDelays/no_null/"
nonull_prefix = "nonull_"

id = 1

time_cols = [29, 30, 37, 38, 40, 41]
delay_cols = [56, 57, 58, 59, 60]

for file_name in os.listdir(refined_path):
    if file_name.endswith(".csv"):
        file_path = os.path.join(refined_path, file_name)

        with open(file_path, newline='') as csvfile:
            reader = csv.reader(csvfile, delimiter='|')

            for row in reader:

                for col in delay_cols:
                    if row[col] == "":
                        row[col] = "0.00"

                for col in time_cols:
                    if len(row[col]) == 4:
                        new_time_col = ["","",""]
                        new_time_col[0] = row[col][:1]
                        if new_time_col[0] == "24":
                            new_time_col[0] == "00"
                        new_time_col[1] = row[col][2:4]
                        new_time_col[2] = "00"
                        new_time_string = ":".join(new_time_col)
                        row[col] = new_time_string

                nonull_filename = nonull_prefix + file_name
                nonull_filepath = os.path.join(nonull_path, nonull_filename)
                with open(nonull_filepath, 'a', newline='') as nn_csvfile:
                    writer = csv.writer(nn_csvfile, delimiter='|')
                    writer.writerow([str(id)] + row[:65])
                nn_csvfile.close()
                id += 1
        csvfile.close()
