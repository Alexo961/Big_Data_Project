import os
import csv

delays_path = "../AirflightDelays/delays/"
nonull_path = "../AirflightDelays/no_null/"
nonull_prefix = "delays_"

delay_cols = [0, 7, 12, 21, 57, 58, 59, 60, 61]

for file_name in os.listdir(nonull_path):
    if file_name.endswith("2016.csv"):
        file_path = os.path.join(nonull_path, file_name)

        with open(file_path, newline='') as csvfile:
            reader = csv.reader(csvfile, delimiter='|')

            for row in reader:

                new_row = ["", "", "", "", "", "", "", "", ""]
                for i, j in enumerate(delay_cols):
                    new_row[i] = row[j]

                delays_filename = nonull_prefix + file_name
                delays_filepath = os.path.join(delays_path, delays_filename)
                with open(delays_filepath, 'a', newline='') as delays_csvfile:
                    writer = csv.writer(delays_csvfile, delimiter='|')
                    writer.writerow(new_row)
                delays_csvfile.close()
        csvfile.close()
