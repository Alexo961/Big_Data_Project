import re
import os
import csv

merged_path = "../AirflightDelays/merged/"
refined_path = "../AirflightDelays/merged_refined"

#reg_ex = r',\s*(?=([^"]*"[^"]*")*[^"]*$)'
#max_splits = 65
#separator = '|'
refined_prefix = "refined_"

for file_name in os.listdir(merged_path):
    if file_name.endswith(".csv"):
        file_path = os.path.join(merged_path, file_name)

        with open(file_path, newline='') as csvfile:
            reader = csv.reader(csvfile)
            for row in reader:
                refined_filename = refined_prefix + file_name
                refined_filepath = os.path.join(refined_path, refined_filename)
                with open(refined_filepath, 'a', newline='') as ref_csvfile:
                    writer = csv.writer(ref_csvfile, delimiter='|')
                    writer.writerow(row[:65])
                ref_csvfile.close()
        csvfile.close()